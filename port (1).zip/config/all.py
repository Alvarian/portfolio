##AWS CONFIG

class keys:
	def __init__(self):
		self.ACCESS_KEY_ID = 'AKIAJJKCT6QGOAU7K4OA'
		self.ACCESS_SECRET_KEY = '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'
		self.REGION_NAME = 'us-east-2'
		self.BUCKET_NAME = 'port-bucket'
		self.EXPECTED_MASTER = 'ivan'
		self.MAIL_SERVER = 'smtp.gmail.com'
		self.MAIL_PORT = 465
		self.MAIL_USERNAME = 'alvarivan88@gmail.com' 
		self.MAIL_PASSWORD = 'skatgjzuwawkycse'
		self.MAIL_USE_TLS = False
		self.MAIL_USE_SSL = True

def test():
  return 'test'	